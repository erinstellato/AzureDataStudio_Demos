/*
	Include query history (install extension)
	Then go to View | Output, and Query History tab
*/

USE [WideWorldImporters];
GO

SELECT TOP 10 *
FROM [Purchasing].[PurchaseOrders] po
JOIN [Purchasing].[PurchaseOrderLines] pl
	ON po.PurchaseOrderID = pl.PurchaseOrderID
JOIN [Purchasing].[Suppliers] s
	ON po.SupplierID = s.SupplierID
JOIN [Purchasing].[SupplierCategories] sc
	ON s.SupplierCategoryID = sc.SupplierCategoryID
JOIN [Purchasing].[SupplierTransactions] st
	ON s.SupplierID = st.SupplierID
	AND pl.PurchaseOrderID = st.PurchaseOrderID


SELECT *
FROM [Purchasing].[PurchaseOrders] po
JOIN [Purchasing].[PurchaseOrderLines] pl
	ON po.PurchaseOrderID = pl.PurchaseOrderID
JOIN [Purchasing].[SupplierTransactions] st
	ON s.SupplierID = st.SupplierID
	AND pl.PurchaseOrderID = st.PurchaseOrderID


SELECT [CustomerID], SUM([AmountExcludingTax])
FROM [Sales].[CustomerTransactions]
WHERE [CustomerID] = 1092
GROUP BY [CustomerID];
GO

USE [WideWorldImportersB];
GO

EXEC [Sales].[usp_GetFullProductInfo] 220 
GO

/*
	Include timeline (explorer) for history to files
*/

EXEC [Sales].[usp_GetFullProductInfo] 401 
GO




